import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Order } from '../Order';

@Component({
  selector: 'app-updatestatus',
  templateUrl: './updatestatus.component.html',
  styleUrls: ['./updatestatus.component.css']
})
export class UpdatestatusComponent implements OnInit {

  orderedproduct: Order[];
  constructor(private service: ServiceService) { }

  status = [
    { id: 1, name: "Placed" },
    { id: 2, name: "InTransit" },
    { id: 3, name: "Delivered" },
    { id: 4, name: "Return Pending" },
    { id: 5, name: "Returned" }
  ];
  selectedValue = null;

  ngOnInit() {
    this.service.getAllOrder().subscribe(data => this.handleSuccessfulResponse(data));
  }
  
  handleSuccessfulResponse(data) {
    this.orderedproduct = data;
  }
  updateStatus() {

  }
}
