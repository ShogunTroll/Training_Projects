export class Order{
    orderId: string;
    //customer: Customer;
    finalAmount: number;
    promoCode: string;
    couponCode: string;
    orderedDate: Date;
    deliveryDate: Date;
    //products: OrderedProduct[];
    status: string;
}