import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Order} from './Order';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  private baseUrl='http://localhost:9090/capstore/';

  constructor(private http:HttpClient) { }

  updatestatus(orderId:number, status:string):Observable<Order[]>{
    console.log(orderId);
    return this.http.put<Order[]>(this.baseUrl+"updatedelstatus"+orderId+"/"+status,"");
  }

  getAllOrder():Observable<Order[]>{
    return this.http.get<Order[]>(this.baseUrl+"getallorder");
  }
}
