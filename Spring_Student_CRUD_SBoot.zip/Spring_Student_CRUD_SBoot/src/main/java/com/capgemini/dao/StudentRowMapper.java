package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capgemini.model.Student;

public class StudentRowMapper implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		int id = rs.getInt("StudentId");
		String name = rs.getString("name");
		Student student = new Student();
		student.setStudentId(id);
		student.setName(name);
		return student;
	}
}
