package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.Student;
import com.capgemini.service.StudentService;

@RestController
@RequestMapping(value = "students")
public class StudentRestController {

	@Autowired
	private StudentService service;

	// http://localhost:9095/students/hello
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String helloWorld() {
		return "Hello Class From REST service";
	}

	// http://localhost:9095/students/
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Student> getAllStudents() {
		List<Student> list = service.findAllStudent();
		return list;
	}

	// http://localhost:9095/students/id
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Student getStudentById(@PathVariable("id") int id) {
		Student student = service.findStudentById(id);
		return student;
	}

	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addStudent(@RequestBody Student obj) {
		service.addStudent(obj);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteStudentById(@PathVariable("id") int id) {
		Student student = service.findStudentById(id);
		service.removeStudent(student);
	}

	@RequestMapping(value = "/", method = RequestMethod.PUT)
	public void updateStudent(@RequestBody Student obj) {
		service.updateStudent(obj);
	}
}
