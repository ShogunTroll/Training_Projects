import { Component, OnInit } from '@angular/core';
import { CustomerService, Transactions, Customer } from '../customer.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  isLogin: boolean = true;
  customers: Customer[] = [];
  //sbalance: number;
  upBal: number;
  service: CustomerService;
  isWithdraw: boolean = true;

  constructor(service: CustomerService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  withdrawAmount(data: any) {
    let caccount_first = this.service.loginAccount;
    var withdraw = this.service.withdrawBalance(caccount_first, data.cbalance)
    withdraw.subscribe((data) => {
      this.upBal = data;
      console.log(data);
    })
    /*var show=this.service.showBalance(caccount_first);
    show.subscribe((data)=>{
      this.sbalance=data;
    });
    if(this.sbalance>=data.data.cbalance)
    {

    }*/
    this.isWithdraw = !this.isWithdraw;
  }

  ngOnInit() {
    this.customers = this.service.getCustomers();
  }
}
