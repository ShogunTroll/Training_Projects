import { Component } from "@angular/core";
import {FormBuilder ,FormGroup, FormArray, FormControl, Validators} from '@angular/forms';
import {Router, ActivatedRoute} from '@angular/router';
import { IUser } from "./user";
import {UserService } from "./user.service";

@Component({
    selector: 'user-login',
    templateUrl: './login.component.html'
})

export class loginUserComponent{

    user: IUser;
    result:boolean;
  constructor(private route: ActivatedRoute, private router:Router, 
    private userService :UserService) {
      this.user=new IUser();
    
  }
 
  onSubmit() {
    
  this.userService.login(this.user.userName,this.user.password).subscribe(data=>{this.result=data;});
  
  if(this.result==true){
  this.router.navigate(['/bankservices'])
   }
   else{
     this.router.navigate(['/login']);
     alert("Invalid credentials");
   }
}
  
}