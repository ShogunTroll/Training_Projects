import { Component, OnInit } from '@angular/core';
import { CustomerService, Transactions, Customer } from '../customer.service';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {

  service:CustomerService;
  trans:Transactions[]=[];

  constructor(service:CustomerService) { 
    this.service=service;
  }

  miniStatement(){
    var print=this.service.miniStatement(this.service.loginAccount);
    print.subscribe((data)=>{
      this.trans=data;
    })
  }

  ngOnInit() {
  }

}
