import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';

import {FormsModule, ReactiveFormsModule} from '@angular/forms'
import{Routes,RouterModule} from '@angular/router';



import { UserService } from './user.service';
import {  AddUserComponent } from './adduser.component';

import { HttpClientModule } from '@angular/common/http';
import { UserListComponent } from './displayuser.component';
import { showBalanceComponent } from './showBalance';
import { MoneyDepositComponent } from './deposit.component';
import { MoneyWithdrawComponent } from './withdraw.component';
import { FundTransferComponent } from './fundTransfer.Component';
import { loginUserComponent } from './login.component';
import { BankServiceComponent } from './BankServices.component';



const appRouts:Routes=[
  { path: './', component: AppComponent },
  { path: 'login', component:loginUserComponent },
  { path: 'users', component: UserListComponent },
  { path: 'bankservices', component: BankServiceComponent},
    { path: 'addusers', component: AddUserComponent },
    { path: 'getbalance', component:showBalanceComponent},
    { path: 'depositmoney', component:MoneyDepositComponent},
    { path: 'withdrawmoney', component:MoneyWithdrawComponent},
    { path: 'transferfund', component:FundTransferComponent}
]

@NgModule({
    imports: [BrowserModule, FormsModule, RouterModule.forRoot(appRouts), ReactiveFormsModule, HttpClientModule],
    declarations: [ AppComponent, AddUserComponent,UserListComponent,showBalanceComponent,MoneyDepositComponent,MoneyWithdrawComponent,FundTransferComponent,loginUserComponent,BankServiceComponent],
    
    bootstrap: [AppComponent],
    providers: [UserService]
})

export class AppModule { }