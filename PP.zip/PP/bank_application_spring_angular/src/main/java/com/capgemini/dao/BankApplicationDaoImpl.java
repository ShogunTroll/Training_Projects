package com.capgemini.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.model.User1;
import com.capgemini.utils.DatabaseUtils;


@Repository
public class BankApplicationDaoImpl implements BankApplicationDao{

	
	
	
	DatabaseUtils con;
	EntityManager manager;
	
	public BankApplicationDaoImpl(){
		con=new DatabaseUtils();
		manager=con.getEntityManager();
	}
	
	 
	
	public double get_Balance(String userName) {
		
		User1 user=manager.find(User1.class,userName);
		double bal=user.getBalance();
		return bal;
	}

	public double deposit_money(String userName,double amount) {
		User1 user=manager.find(User1.class,userName);
		System.out.print("hi1");
		double bal=user.getBalance();
		System.out.print("hi2");
		double balance=bal+amount;
		user.setBalance(balance);
		System.out.print("hi3");

		return balance;
	}

	public double Withdraw_money(String userName,double amount) {
		double balance=0.0;
		User1 user=manager.find(User1.class,userName);
		double bal=user.getBalance();
		if(bal>amount){
			balance=bal-amount;
			user.setBalance(balance);
		}
		else{
			System.err.println("low balance");
		}
			
				
		return bal;
	}

	public double fund_Transfer(String userName,String username1,double amount) {
		
		double balance=0.0;
		User1 user=manager.find(User1.class,userName);
		double bal=user.getBalance();
		if(bal>amount){
			balance=bal-amount;
			user.setBalance(balance);
		}
		else{
			System.err.println("low balance");
		}
		
		User1 user1=manager.find(User1.class,username1);
		double bal1=user1.getBalance();
		bal1=bal1+amount;
		user1.setBalance(bal1);
		return balance;
	}

	

	public void createUserAccount(User1 user) {
		System.out.println("dao");
	        manager.persist(user);
	      
	        
    	}

		public void printTransfer() {
			
			}

		public boolean validate(String userName) {
			return false;
		}

		public boolean matchPass(String userName, String password) {
			User1 user=manager.find(User1.class, userName);
			String pass=user.getPassword();
			if(user.equals(null)){
				return false;
			}
			else if(pass.equals(password)){
					return true;
				}
			else{
				return false;
			}
			}
		



		public void beginTransaction() {
			manager.getTransaction().begin();
		}



		public void commitTransaction() {
			manager.getTransaction().commit();
		}



		public List getAllUsers() {
			String query="From User1";
			TypedQuery<User1> tquery=manager.createQuery(query,User1.class);
			List<User1> list=tquery.getResultList();
			return list;
		}



		
		}


