package com.capgemini.dao;
import java.util.List;

import com.capgemini.model.User1;

public interface BankApplicationDao {

	
	
	public double deposit_money(String userName, double amount);
	public double Withdraw_money(String userName,double amount);
	public double fund_Transfer(String userName,String username1,double amount);
    public boolean validate(String userName) ;
    public boolean matchPass(String userName,String password) ;
	public void createUserAccount(User1 user);
	public double get_Balance(String userName);
	public void printTransfer();
	public abstract void beginTransaction();
	public abstract void commitTransaction();
	public List getAllUsers();
}
