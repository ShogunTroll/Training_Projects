package com.cg.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DiscountCode {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	
	String name;
	double value;
	
	@Enumerated(EnumType.STRING)
	DiscountCodeType type;
	
	Date startDate;
	
	Date endDate;

//	String category;

	double minimumAmount;
}
