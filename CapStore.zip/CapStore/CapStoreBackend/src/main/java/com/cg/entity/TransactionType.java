package com.cg.entity;

public enum TransactionType {
	DEBIT, CREDIT
}
