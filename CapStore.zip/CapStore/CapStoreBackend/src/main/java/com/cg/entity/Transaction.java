package com.cg.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Transaction {
	@Id
	String id;
	String orderId;
	Date transactionDate;
	double amount;
	TransactionType type;
	TransactionStatus status;
	
}
