package com.cg.entity;

public enum MerchantStatus {
	APPROVED, PENDING, FAILED
}
