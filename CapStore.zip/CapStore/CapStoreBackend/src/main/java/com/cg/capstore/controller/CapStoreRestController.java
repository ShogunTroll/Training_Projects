package com.cg.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.cg.capstore.entities.Customer;
import com.cg.capstore.services.CapStoreService;
import com.cg.entity.*;

@CrossOrigin
@RestController
@RequestMapping(value = "capstore")
public class CapStoreRestController {

	@Autowired
	private CapStoreService service;

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public void hello() {
		System.out.println("Hello");
	}

	/*
	 * @PostMapping(path = "/createCustomer") public Customer
	 * addCustomerInCapStore(@RequestBody Customer customer) { return
	 * service.addCustomerInCapStore(customer); }
	 * 
	 * @RequestMapping(path = "/getCustomer", method = RequestMethod.POST) public
	 * Customer authenticateCustomerLoginDetails(@RequestBody Customer customer) {
	 * return service.authenticateCustomerLoginDetails(customer); }
	 */
	//http://localhost:9090/capstore/detailbyorderid/{orderid}
	@RequestMapping(path = "/detailbyorderid/{orderid}", method = RequestMethod.GET)
	public List<Order> displayDetailsByOrderID(@PathVariable String orderID)
	
	{
		List<Order> list = new ArrayList<Order>();
		list = service.displayDetailsByOrderID(orderID);
		return list;

	}
	
	  @RequestMapping(path = "/detailbymerchantid/{merchantid}", method = RequestMethod.GET) public
	  List<Order> displayDetailsByMerchantID(@PathVariable int merchantID) 
	  {
	  List<Order> list = new ArrayList<Order>(); list =
	  service.displayDetailsByMerchantID(merchantID); return list; 
	  }
	 

	  @RequestMapping(path = "/detailbycategory/{category}",method = RequestMethod.GET)
	  public List<Order> displayDetailsByCategory(@PathVariable String category)
	  {
		  List<Order> list=new ArrayList<Order>();
		  list=service.displayDetailsBycategory(category);
		  return list;
	  }

}
