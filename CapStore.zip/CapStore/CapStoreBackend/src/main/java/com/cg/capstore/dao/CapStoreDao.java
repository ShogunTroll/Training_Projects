package com.cg.capstore.dao;

import java.util.List;

//import com.cg.capstore.entities.Customer;
import com.cg.entity.Customer;
import com.cg.entity.Order;

public interface CapStoreDao {
	
//public abstract Customer createCustomer(Customer customer);
	
	//public abstract Customer verifyCustomerLoginCredentials(Customer customer);
	
	
	
	
	public abstract List<Order> displayDetailsByOrderID(String orderID);
	
	public abstract List<Order> displayDetailsByMerchantID(int merchantID);

	public abstract List<Order> displayDetailsByCategory(String category);
	
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();




	
}
