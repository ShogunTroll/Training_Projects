package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.entity.Customer;
import com.cg.entity.Order;

//import com.cg.capstore.entities.Customer;

@Repository
public class CapStoreDaoImpl implements CapStoreDao {

	private EntityManager entityManager;

	TypedQuery<Customer> query;

	public CapStoreDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	/*
	 * @Override public Customer createCustomer(Customer customer) {
	 * entityManager.persist(customer); return customer; }
	 * 
	 * @Override public Customer verifyCustomerLoginCredentials(Customer customer) {
	 * 
	 * query = entityManager.createQuery(
	 * "select c from Customer c where c.mobileNo =:mobile and c.password =:password"
	 * , Customer.class); query.setParameter("mobile", customer.getMobileNo());
	 * query.setParameter("password", customer.getPassword()); if
	 * (query.getSingleResult() == null) { query = entityManager.createQuery(
	 * "select c from Customer c where c.email =:email and c.password =:password",
	 * Customer.class); query.setParameter("email", customer.getEmail());
	 * query.setParameter("password", customer.getPassword()); if
	 * (query.getSingleResult() == null) { return null; } else { return
	 * query.getSingleResult(); } } else { return query.getSingleResult(); }
	 * 
	 * }
	 */

	@Override
	public List<Order> displayDetailsByOrderID(String orderID) {

		Query query = entityManager.createQuery("select o from order o where o.orderID=:orderID", Order.class);
		query.setParameter("orderId", orderID);

		List<Order> list = query.getResultList();

		return list;
	}

	@Override
	public List<Order> displayDetailsByMerchantID(int merchantID) {

		Query query = entityManager.createQuery("select o from order o where o.OrderedProduct.Product.Merchant.merchantId=:merchantID", Order.class);
		query.setParameter("merchantId", merchantID);

		List<Order> list = query.getResultList();

		return list;
	}

	@Override
	public List<Order> displayDetailsByCategory(String category) {

		

		Query query = entityManager.createQuery("select o from order o where o.OrderedProduct.Product.category=:category", Order.class);
		query.setParameter("category", category);

		List<Order> list = query.getResultList();

		return list;
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

}
