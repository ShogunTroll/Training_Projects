package com.cg.capstore.services;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.entity.Order;

//import com.cg.capstore.entities.Customer;

public interface CapStoreService {
	
	//public abstract Customer addCustomerInCapStore(Customer customer);
	
	//public abstract Customer authenticateCustomerLoginDetails(Customer customer);

	public abstract List<Order> displayDetailsByOrderID(String orderID);

	public abstract List<Order> displayDetailsByMerchantID(int merchantID);

	public abstract List<Order> displayDetailsBycategory(String category);
	

}
