package com.cg.capstore.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CapStoreDao;
//import com.cg.capstore.entities.Customer;
import com.cg.entity.Customer;
import com.cg.entity.Order;

@Service
public class CapStoreServiceImpl implements CapStoreService {

	@Autowired
	private CapStoreDao dao;

	/*
	 * @Override public Customer addCustomerInCapStore(Customer customer) {
	 * dao.beginTransaction(); Customer customerDetails =
	 * dao.createCustomer(customer); dao.commitTransaction(); return
	 * customerDetails; }
	 * 
	 * @Override public Customer authenticateCustomerLoginDetails(Customer customer)
	 * { dao.beginTransaction(); Customer customerDetails =
	 * dao.verifyCustomerLoginCredentials(customer); dao.commitTransaction(); return
	 * customerDetails; }
	 */

	@Override
	public List<Order> displayDetailsByOrderID(String orderID) {

		dao.beginTransaction();
		List<Order> list = new ArrayList<Order>();
		list = dao.displayDetailsByOrderID(orderID);
		dao.commitTransaction();
		return list;
	}

	@Override
	public List<Order> displayDetailsByMerchantID(int merchantID) {

		dao.beginTransaction();
		List<Order> list = new ArrayList<Order>();
		list = dao.displayDetailsByMerchantID(merchantID);
		dao.commitTransaction();
		return list;
		
	}

	@Override
	public List<Order> displayDetailsBycategory(String category) {
		dao.beginTransaction();
		List<Order> list = new ArrayList<Order>();
		list = dao.displayDetailsByCategory(category);
		dao.commitTransaction();
		return list;
		
	}

}
