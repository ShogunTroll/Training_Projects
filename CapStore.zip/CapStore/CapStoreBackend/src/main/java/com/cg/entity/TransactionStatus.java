package com.cg.entity;

public enum TransactionStatus {
	SUCCESS, FAILED
}
