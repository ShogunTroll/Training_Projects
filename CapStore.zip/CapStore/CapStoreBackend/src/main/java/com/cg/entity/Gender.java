package com.cg.entity;

public enum Gender {
	MALE, FEMALE, OTHER
}
