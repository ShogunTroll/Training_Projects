package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_master")
public class Admin {
	@Id
	String adminId;
	
	String authToken;
	
	@Column(unique = true)
	String email;
	
	@Column(unique = true)
	long mobileNumber;
	
	String password;
	
	String securityQuestion;
	
	String answer;
	
}
