package com.cg.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="orderMaster")
public class Order {
	@Id
	String orderId;
	
	@ManyToOne
	Customer customer;
	
	double finalAmount;
	
	String promoCode;
	String couponCode;
	Date deliveryDate;
	
	Date orderedDate;
	
	
	
	@ManyToMany
	List<OrderedProduct> products;
	
	@Enumerated(EnumType.STRING)
	OrderStatus status;
	
	
	
}
