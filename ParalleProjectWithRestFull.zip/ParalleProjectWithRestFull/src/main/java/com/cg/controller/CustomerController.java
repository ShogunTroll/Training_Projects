package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.CustomerDetails;
import com.cg.entities.TransactionDetails;
import com.cg.exception.AccountNotFoundException;
import com.cg.service.IService;

@RestController
@RequestMapping("/xyz")
@CrossOrigin(origins="http://localhost:5200")
public class CustomerController {
	@Autowired
	IService service;

	@PostMapping("/create")
	@CrossOrigin(origins="http://localhost:5200")
	public CustomerDetails createAccount(@Valid @RequestBody CustomerDetails customerDetails) throws AccountNotFoundException {
		return service.createAccount(customerDetails);
	}

	@GetMapping("/showDetails/{accNo}")
	@CrossOrigin(origins="http://localhost:5200")
	public CustomerDetails accountsDetails(@PathVariable Long accNo) throws AccountNotFoundException {
		return service.accountsDetails(accNo);
	}
	
	@GetMapping("/showAllAccounts")
	@CrossOrigin(origins="http://localhost:5200")
	public List<CustomerDetails> showAllAccounts(){
		return service.showAllAccounts();
	}

	@GetMapping("/showBalance/{accNo}")
	@CrossOrigin(origins="http://localhost:5200")
	public Double showBalance(@PathVariable Long accNo) throws AccountNotFoundException {
		return service.showBalance(accNo);

	}

	@PutMapping("/deposit/{accNo}/{amt}")
	@CrossOrigin(origins="http://localhost:5200")
	public Double deposit(@Valid @PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		return service.deposit(accNo, amt);
		
	}

	@PutMapping("/withdraw/{accNo}/{amt}")
	@CrossOrigin(origins="http://localhost:5200")
	public Double withdraw(@Valid @PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		return service.withdraw(accNo, amt);
	}

	@PutMapping("/fundTransfer/{accNo}/{amount}/{accNo1}")
	@CrossOrigin(origins="http://localhost:5200")
	public Double fundTransfer(@Valid @PathVariable Long accNo, @PathVariable Double amount,
			@PathVariable Long accNo1) throws AccountNotFoundException {
		return service.fundTransfer(accNo, amount, accNo1);
	}

	@GetMapping("/print/{accNo}")
	@CrossOrigin(origins="http://localhost:5200")
	public List<TransactionDetails> printTransaction(@PathVariable Long accNo) {
		return service.printTransaction(accNo);
	}

}
