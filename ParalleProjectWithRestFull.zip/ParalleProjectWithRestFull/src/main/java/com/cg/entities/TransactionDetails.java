package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transdetails")
public class TransactionDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "b")
	private long tid;
	private long taccount_sender;
	private long taccount_reciver;
	private double tamount;
	private String ttype;
	
	public long getTid() {
		return tid;
	}
	public void setTid(long tid) {
		this.tid = tid;
	}
	public long getTaccount_sender() {
		return taccount_sender;
	}
	public void setTaccount_sender(long taccount_sender) {
		this.taccount_sender = taccount_sender;
	}
	public long getTaccount_reciver() {
		return taccount_reciver;
	}
	public void setTaccount_reciver(long taccount_reciver) {
		this.taccount_reciver = taccount_reciver;
	}
	public double getTamount() {
		return tamount;
	}
	public void setTamount(double tamount) {
		this.tamount = tamount;
	}
	public String getTtype() {
		return ttype;
	}
	public void setTtype(String ttype) {
		this.ttype = ttype;
	}
	
	@Override
	public String toString() {
		return "TransactionDetails [tid=" + tid + ", taccount_sender=" + taccount_sender + ", taccount_reciver="
				+ taccount_reciver + ", tamount=" + tamount + ", ttype=" + ttype + "]";
	}

	public TransactionDetails(long tid, long taccount_sender, long taccount_reciver, double tamount, String ttype) {
		super();
		this.tid = tid;
		this.taccount_sender = taccount_sender;
		this.taccount_reciver = taccount_reciver;
		this.tamount = tamount;
		this.ttype = ttype;
	}
	
	public TransactionDetails() {
		super();
	}
	
}
