package com.cg.capstore.enums;

public enum TransactionStatus {
	SUCCESS, FAILED
}
