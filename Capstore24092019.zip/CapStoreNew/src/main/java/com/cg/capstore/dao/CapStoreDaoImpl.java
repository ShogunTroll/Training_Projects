package com.cg.capstore.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.Pack200;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.message.TimestampMessage;
import org.aspectj.weaver.ast.Test;
import org.springframework.stereotype.Repository;

import com.cg.capstore.entity.Address;
import com.cg.capstore.entity.Admin;
import com.cg.capstore.entity.CartItems;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Order;
import com.cg.capstore.entity.OrderItem;
import com.cg.capstore.entity.Product;

//import com.cg.capstore.entities.Customer;

public class CapStoreDaoImpl {

	private EntityManager em;

	TypedQuery<Customer> query;

	public void createAdmin() {
		// TEST ADMIN
		Admin admin = new Admin();
		admin.setEmail("admin@gmail.com");
		admin.setMobileNumber(9999999999L);
		admin.setPassword("admin");
		em.getTransaction().begin();
		em.persist(admin);
		em.getTransaction().commit();
	}
	
	public void createMerchantAndProduct() {
		Merchant merchant = new Merchant();
		merchant.setMerchantName("Cloud Tail");
		merchant.setEmail("merchsdfant@gmail.com");
		merchant.setPassword("merchant");
		merchant.setAddress(new Address());
		
		List<Product> pList = new ArrayList<Product>();
		Product p1 = new Product();
		
		p1.setName("Soap");
		p1.setMerchant(merchant);
		
		Product p2 = new Product();
		p2.setName("Tea");
		p2.setMerchant(merchant);
		
		pList.add(p1);
		pList.add(p2);

		merchant.setProducts(pList);
		
		em.getTransaction().begin();
		em.persist(merchant);
		em.getTransaction().commit();
		
		System.out.println(em.find(Product.class, 3L));
	}

	public void createCustomer() {
		Customer customer = new Customer();
		customer.setCustomerName("Yello");
		List<Address> addr=new ArrayList<Address>();
		addr.add(new Address());
		customer.setAddresses(addr);
		
		Set<Product> wishlist = new HashSet<Product>();
		Product p1 = em.find(Product.class, 3L);
		Product p2 = em.find(Product.class, 4L);
		wishlist.add(p1);
		wishlist.add(p2);
		
		customer.setWishlist(wishlist);
		
		Set<CartItems> items = new HashSet<CartItems>();
		CartItems c1= new CartItems();
		c1.setCartQuantity(2);
		c1.setProduct(p1);
		items.add(c1);
		customer.setItems(items);
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		System.out.println(em.find(Customer.class, 5L));
		
	}
	
	public void order(){
		Customer customer=em.find(Customer.class, 5L);
		List<OrderItem> items = new ArrayList<>();
		OrderItem o1= new OrderItem();
		o1.setQuantity(10);
		o1.setPaidAmount(100.0);
		o1.setPromoCode("DREAM10");
		
		Product p1 = em.find(Product.class, 3L);
		o1.setProduct(p1);
		Order order = new Order();
		o1.setOrder(order);
		o1.setCustomer(customer);
		items.add(o1);
		order.setItems(items);
		em.getTransaction().begin();
		em.persist(order);
		em.getTransaction().commit();
		System.out.println(em.find(Order.class,8L));
		
	}
	public void test(){
		TypedQuery<CartItems> query = em.createQuery("select c from CartItems c where c.product.productId=:productId", CartItems.class);
		query.setParameter("productId", 3L);
		System.out.println(query.getSingleResult());
	}
	public CapStoreDaoImpl() {
		em = JPAUtil.getEntityManager();
	}

	
	public void commitTransaction() {
		em.getTransaction().commit();

	}

	public void beginTransaction() {
		em.getTransaction().begin();

	}

}
