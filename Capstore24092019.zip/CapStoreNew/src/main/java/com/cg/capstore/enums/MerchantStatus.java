package com.cg.capstore.enums;

public enum MerchantStatus {
	APPROVED, PENDING, FAILED
}
