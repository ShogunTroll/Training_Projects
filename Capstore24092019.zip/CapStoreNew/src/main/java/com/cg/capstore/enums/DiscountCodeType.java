package com.cg.capstore.enums;

public enum DiscountCodeType {
	PROMO, COUPON
}
