package com.cg.capstore.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Misc {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	double minCartValue;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public double getMinCartValue() {
		return minCartValue;
	}
	public void setMinCartValue(double minCartValue) {
		this.minCartValue = minCartValue;
	}
	
}
