package com.cg.capstore.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cg.capstore.enums.Gender;

@Entity
@Table(name = "customer")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long customerId;

	String authToken;

	String customerName;

	@OneToMany(cascade=CascadeType.ALL)
	List<Address> addresses;

	@Column(unique = true)
	String email;
	
	@Column(unique = true)
	String mobileNo;

	@Enumerated(EnumType.STRING)
	Gender gender;

	@ManyToMany
	Set<Product> wishlist;

	@OneToMany(cascade= CascadeType.ALL)
	Set<CartItems> items;

	@OneToMany(cascade= CascadeType.ALL)
	List<Order> orders;

	String password;

	String securityQuestion;

	String answer;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public List<Address> SetAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Set<Product> getWishlist() {
		return wishlist;
	}

	public void setWishlist(Set<Product> wishlist) {
		this.wishlist = wishlist;
	}

	public Set<CartItems> getItems() {
		return items;
	}

	public void setItems(Set<CartItems> items) {
		this.items = items;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", wishlist=" + wishlist + ", items=" + items + ", orders=" + orders +  "]";
	}
	
	
}
