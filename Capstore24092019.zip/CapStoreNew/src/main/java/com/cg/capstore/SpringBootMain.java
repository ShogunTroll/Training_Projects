package com.cg.capstore;

import com.cg.capstore.dao.CapStoreDaoImpl;

public class SpringBootMain {
	public static void main(String[] args) {
		CapStoreDaoImpl dao=new CapStoreDaoImpl();
		dao.createMerchantAndProduct();
		dao.createCustomer();
		dao.order();
		dao.test();
	}
}
