package com.cg.capstore.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.cg.capstore.enums.TransactionType;

@Entity
public class Revenue {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long revenueId;
	@OneToOne
	OrderItem item;
	//PERCENTAGE OF FINAL AMOUNT OF THAT ORDER
	double revenueAmount;
	TransactionType type;
	
	public long getRevenueId() {
		return revenueId;
	}
	public void setRevenueId(long revenueId) {
		this.revenueId = revenueId;
	}
	public OrderItem getItem() {
		return item;
	}
	public void setItem(OrderItem item) {
		this.item = item;
	}
	public double getRevenueAmount() {
		return revenueAmount;
	}
	public void setRevenueAmount(double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	public TransactionType getType() {
		return type;
	}
	public void setType(TransactionType type) {
		this.type = type;
	}
	
	
}
