package com.cg.capstore.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cg.capstore.enums.AddressType;


@Entity
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long addressId;
	String fullname;
	long mobileNumber;
	int pincode;
	String houseNo;
	String locality;
	String landmark;
	String city;
	
	String state;
	
	public Address(){}
	
	public Address(long addressId, String fullname, long mobileNumber, int pincode, String houseNo, String locality,
			String landmark, String city, String state, AddressType addressType) {
		this.fullname = fullname;
		this.mobileNumber = mobileNumber;
		this.pincode = pincode;
		this.houseNo = houseNo;
		this.locality = locality;
		this.landmark = landmark;
		this.city = city;
		this.state = state;
		this.addressType = addressType;
	}

	@Enumerated(EnumType.STRING)
	AddressType addressType;

	public long getAddressId() {
		return addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public AddressType getAddressType() {
		return addressType;
	}

	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}
	
	
}
