package com.cg.entity;

public enum AddressType {
	HOME, OFFICE
}
