package com.cg.entity;

public class Misc {

}
