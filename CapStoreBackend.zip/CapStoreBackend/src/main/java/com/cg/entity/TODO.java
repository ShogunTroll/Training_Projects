package com.cg.entity;

public class TODO {
// TO decide the place for min cart amount
}
