package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {
	@Id
	String productId;
	String name;
	String brand;
	
	double price;
	String imageUrl;
	String category;
	String description;
	
	@Enumerated(EnumType.STRING)
	ProductFor productFor;
	String productType;
	
	@ManyToOne
	Merchant merchant;
	double discountPercentage;
	long viewCount;
	
	int quantity;
}
