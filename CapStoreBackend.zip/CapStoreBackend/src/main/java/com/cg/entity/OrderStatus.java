package com.cg.entity;

public enum OrderStatus {
	PLACED, IN_TRANSIT, DELIVERED, RETURN_PENDING, RETURNED
}
