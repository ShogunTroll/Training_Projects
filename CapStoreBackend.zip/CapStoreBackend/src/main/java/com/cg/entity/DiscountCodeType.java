package com.cg.entity;

public enum DiscountCodeType {
	PROMO, COUPON
}
