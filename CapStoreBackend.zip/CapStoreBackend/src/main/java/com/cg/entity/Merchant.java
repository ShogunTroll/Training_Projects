package com.cg.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "merchant")
public class Merchant {
	@Id
	String merchantId;
	String token;
	
	String merchantName;
	@OneToOne
	Address address;
	
	@Column(unique = true)
	long mobileNumber;
	
	@Column(unique = true)
	String email;
	
	String password;
	
	String shopName;
	
	@OneToMany
	List<Product> products;
	
	@OneToMany
	List<OrderedProduct> orders;
	
	MerchantStatus status;
}
