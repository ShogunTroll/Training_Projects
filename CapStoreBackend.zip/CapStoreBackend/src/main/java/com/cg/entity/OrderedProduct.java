package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ordered")
public class OrderedProduct {
	@Id
	long orderedProductId;
	int rating;
	String feedback;
	double quantity;
	@OneToOne
	Product product;
}
