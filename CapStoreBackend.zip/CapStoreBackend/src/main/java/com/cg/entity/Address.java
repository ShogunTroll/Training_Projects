package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;


@Entity
public class Address {
	@Id
	long addressId;
	String fullname;
	long mobileNumber;
	int pincode;
	String houseNo;
	String locality;
	String landmark;
	String city;
	
	@Enumerated(EnumType.STRING)
	States state;
	
	@Enumerated(EnumType.STRING)
	AddressType addressType;
}
