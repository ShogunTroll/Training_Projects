package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Revenue {
	@Id
	long revenueId;
	@OneToOne
	Order order;
	double revenueAmount;
	TransactionType type;
	
}
