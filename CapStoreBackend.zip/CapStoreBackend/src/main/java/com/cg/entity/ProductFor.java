package com.cg.entity;

public enum ProductFor {
	MEN, WOMEN, KIDS, GENERAL
}
