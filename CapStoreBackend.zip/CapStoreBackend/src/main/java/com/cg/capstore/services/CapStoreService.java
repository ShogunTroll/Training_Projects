package com.cg.capstore.services;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.entity.Order;

//import com.cg.capstore.entities.Customer;

public interface CapStoreService {
	
	public abstract Customer addCustomerInCapStore(Customer customer);
	
	public abstract Customer authenticateCustomerLoginDetails(Customer customer);
	
	public abstract void updateDeliveryStatus(String orderid, String status);
	
	public abstract List<Order> getAllOrder();

}
