package com.cg.capstore.dao;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.entity.Customer;
import com.cg.entity.Order;
import com.cg.entity.OrderStatus;

//import com.cg.capstore.entities.Customer;

@Repository
public class CapStoreDaoImpl implements CapStoreDao {

	private EntityManager entityManager;

	TypedQuery<Customer> query;

	public CapStoreDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public Customer createCustomer(Customer customer) {
		entityManager.persist(customer);
		return customer;
	}

	@Override
	public Customer verifyCustomerLoginCredentials(Customer customer) {

		query = entityManager.createQuery(
				"select c from Customer c where c.mobileNo =:mobile and c.password =:password", Customer.class);
		query.setParameter("mobile", customer.getMobileNo());
		query.setParameter("password", customer.getPassword());
		if (query.getSingleResult() == null) {
			query = entityManager.createQuery(
					"select c from Customer c where c.email =:email and c.password =:password", Customer.class);
			query.setParameter("email", customer.getEmail());
			query.setParameter("password", customer.getPassword());
			if (query.getSingleResult() == null) {
				return null;
			} else {
				return query.getSingleResult();
			}
		} else {
			return query.getSingleResult();
		}

	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	@Override
	public void updateDeliveryStatus(String orderid, String status) {
		Query query = entityManager.createQuery("UPDATE Order o SET o.status=:sts WHERE orderId=:oid");
		if (status.equals("Placed")) {
			OrderStatus os = OrderStatus.PLACED;
			query.setParameter("sts", os);
			query.setParameter("oid", orderid);
			query.executeUpdate();
		} else if (status.equals("Delivered")) {
			OrderStatus os = OrderStatus.DELIVERED;
			query.setParameter("sts", os);
			query.setParameter("oid", orderid);
			query.executeUpdate();
		} else if (status.equals("InTransit")) {
			OrderStatus os = OrderStatus.IN_TRANSIT;
			query.setParameter("sts", os);
			query.setParameter("oid", orderid);
			query.executeUpdate();
		} else if (status.contentEquals("Return Pending")) {
			OrderStatus os = OrderStatus.RETURN_PENDING;
			query.setParameter("sts", os);
			query.setParameter("oid", orderid);
			query.executeUpdate();
		} else if (status.contentEquals("Returned")) {
			OrderStatus os = OrderStatus.RETURNED;
			query.setParameter("sts", os);
			query.setParameter("oid", orderid);
			query.executeUpdate();
		}
	}

	@Override
	public List<Order> getAllOrder() {
		Query query = entityManager.createQuery("From Order");
		List<Order> list = query.getResultList();
		return list;
	}
}
