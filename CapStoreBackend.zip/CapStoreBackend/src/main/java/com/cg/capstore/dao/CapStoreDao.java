package com.cg.capstore.dao;

import java.util.List;

//import com.cg.capstore.entities.Customer;
import com.cg.entity.Customer;
import com.cg.entity.Order;

public interface CapStoreDao {

	public abstract Customer createCustomer(Customer customer);

	public abstract Customer verifyCustomerLoginCredentials(Customer customer);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

	public abstract void updateDeliveryStatus(String orderid, String status);
	
	public abstract List<Order> getAllOrder();
}
