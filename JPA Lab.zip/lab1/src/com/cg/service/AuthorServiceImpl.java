package com.cg.service;

import com.cg.dao.AuthorDAOImpl;
import com.cg.entities.Author;

public class AuthorServiceImpl implements AuthorService {

	AuthorDAOImpl dao = new AuthorDAOImpl();

	@Override
	public void addAuthor(Author a) {
		dao.addAuthor(a);

	}

	@Override
	public void removeAuthor(int aid) {

		dao.removeAuthor(dao.findAuthor(aid));

	}

	@Override
	public void updateAuthor(Author a) {
		dao.updateAuthor(a);

	}

	@Override
	public Author findAuthor(int aid) {
		return dao.findAuthor(aid);
	}

}
