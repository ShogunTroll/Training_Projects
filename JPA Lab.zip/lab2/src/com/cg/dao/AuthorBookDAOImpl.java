package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.DBUtil.Db;
import com.cg.entities.Author;
import com.cg.entities.Book;

public class AuthorBookDAOImpl implements AuthorBookDAO {

	Db con;
	EntityManager manager;

	public AuthorBookDAOImpl() {
		con = new Db();
		manager = con.getManager();
	}

	private void addBooks() {
		Book book = new Book();
		book.setBookIsbn(1);
		book.setTitle("Java");
		book.setPrice(45000);

		Book book1 = new Book();
		book1.setBookIsbn(2);
		book1.setTitle("Python");
		book1.setPrice(25000);

		Book book2 = new Book();
		book2.setBookIsbn(3);
		book2.setTitle("Data Structures");
		book2.setPrice(20000);

		Book book3 = new Book();
		book3.setBookIsbn(4);
		book3.setTitle("Algorithms");
		book3.setPrice(15000);

		// now define first Boook and add few products in it
		Author author1 = new Author();
		author1.setAuthorId(1001);
		author1.setAuthorName("sumita");

		author1.addbook(book3);
		author1.addbook(book2);

		// now define second order and add few products in it
		Author secondAuthor = new Author();
		secondAuthor.setAuthorId(1002);
		secondAuthor.setAuthorName("bryant");

		secondAuthor.addbook(book1);
		secondAuthor.addbook(book2);

		// save orders using entity manager
		manager.getTransaction().begin();
		manager.persist(author1);
		manager.persist(book1);
		manager.persist(book2);
		manager.persist(book3);
		manager.persist(secondAuthor);
		manager.getTransaction().commit();

	}

	@Override
	public List<Book> getAllBooks() {
		addBooks();

		String query = "select b from Book b";
		TypedQuery<Book> t = manager.createQuery(query, Book.class);
		return t.getResultList();
	}

	@Override
	public List<Book> getBooksByAuthor(String author_name) {
		Query query = manager.createQuery("select b from Book b join b.authorList a where a.authorName=:author_name");
		query.setParameter("author_name", author_name);
		return query.getResultList();
	}

	@Override
	public List<Book> getBooksByPriceRange(double min, double max) {
		String query = "select b from Book b where price between " + min + " and " + max;
		TypedQuery<Book> t = manager.createQuery(query, Book.class);
		return t.getResultList();
	}

	@Override
	public List<String> getAuthorName(long b_id) {
		Query query = manager.createQuery("select a.authorName from Author a join a.bookList b where b.bookIsbn=:b_id");
		query.setParameter("b_id", b_id);
		return query.getResultList();
	}

}
