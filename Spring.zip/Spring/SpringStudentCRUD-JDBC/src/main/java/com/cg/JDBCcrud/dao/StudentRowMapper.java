package com.cg.JDBCcrud.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.JDBCcrud.entities.Student;

public class StudentRowMapper implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {

		
		int id= rs.getInt("StudentId");
		String name=rs.getString("Name");
		Student student= new Student();
		student.setStudentId(id);
		student.setName(name);
		
		return student;
	}

}
