package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.model.Student;
import com.capgemini.service.StudentService;

@Controller("")
public class StudentContoller {

	@Autowired
	private StudentService service;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String homepage() {
		return "index";
	}

	@RequestMapping(path = "display", method = RequestMethod.GET)
	public String displayStudent(Model model) {
		List<Student> list = service.findAllStudent();
		System.out.println(list);
		model.addAttribute("listStudent", list);
		return "displaystudent";
	}

	@RequestMapping(path = "add", method = RequestMethod.GET)
	public String addStudent() {
		return "addstudent";
	}

	@RequestMapping(path = "add", method = RequestMethod.POST)
	public String addToDatabase(@RequestParam("studentId") int id, @RequestParam("studentName") String name) {

		Student student = new Student();
		student.setStudentId(id);
		student.setName(name);
		service.addStudent(student);
		return "redirect:display";
	}

	@RequestMapping(path = "delete", method = RequestMethod.GET)
	public String deleteStudent(@RequestParam("id") int id) {
		Student student = new Student();
		student.setStudentId(id);
		service.removeStudent(student);
		return "redirect:display";
	}

	@RequestMapping(path = "update", method = RequestMethod.GET)
	public String updateStudent(@RequestParam("id") int id, @RequestParam("name") String name, Model model) {
		Student student = new Student();
		student.setName(name);
		student.setStudentId(id);
		//service.updateStudent(student);
		model.addAttribute("student", student);
		return "updatestudent";
	}

	@RequestMapping(path = "update", method = RequestMethod.POST)
	public String updateToDatabase(@RequestParam("studentId") int id, @RequestParam("studentName") String name) {
		Student student = new Student();
		student.setStudentId(id);
		student.setName(name);
		service.updateStudent(student);
		return "redirect:display";
	}
}
