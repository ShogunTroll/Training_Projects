package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.StudentDao;
import com.capgemini.model.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao dao;

	/*
	 * public StudentServiceImpl(StudentDao dao) { this.dao = dao; }
	 */

	@Override
	public void addStudent(Student student) {
		dao.addStudent(student);
	}

	@Override
	public void updateStudent(Student student) {
		dao.updateStudent(student);
	}

	@Override
	public void removeStudent(Student student) {
		dao.removeStudent(student);
	}

	@Override
	public Student findStudentById(int id) {
		Student student = dao.getStudentById(id);
		return student;
	}

	@Override
	public List<Student> findAllStudent() {
		return dao.getAllStudents();
	}
}
