package com.capgemini.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.capgemini.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public StudentDaoImpl() {

	}

	@Override
	public Student getStudentById(int id) {
		String query = "SELECT * FROM Students WHERE studentId=" + id;
		List<Student> list = jdbcTemplate.query(query, new StudentRowMapper());
		return list.get(0);
	}

	@Override
	public void addStudent(Student student) {
		String query = "INSERT INTO Students(studentId, name) " + "values(" + student.getStudentId() + ",'"
				+ student.getName() + "')";
		System.out.println(query);
		jdbcTemplate.update(query);
	}

	@Override
	public void removeStudent(Student student) {
		String query = "DELETE FROM Students WHERE StudentId=" + student.getStudentId();

		jdbcTemplate.update(query);
	}

	@Override
	public void updateStudent(Student student) {
		String query = "UPDATE Students SET name='" + student.getName() + "'WHERE studentId=" + student.getStudentId();
		jdbcTemplate.update(query);
	}

	@Override
	public void beginTransaction() {
	}

	@Override
	public void commitTransaction() {

	}

	@Override
	public List<Student> getAllStudents() {
		String query = "SELECT * FROM Students ORDER BY studentid";
		List<Student> list = jdbcTemplate.query(query, new StudentRowMapper());
		return list;
	}
}
