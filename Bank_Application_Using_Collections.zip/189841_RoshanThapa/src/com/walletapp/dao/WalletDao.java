package com.walletapp.dao;

import com.walletapp.model.WalletAccount;

public interface WalletDao {
	public boolean createAccount(WalletAccount wa);

	public double readBalance(int accountNumber);

	public double updateMoney(int accountNumber, double money);

	public double transferMoney(int accountNumberFrom, int accountNumberTo, double money);

	public WalletAccount deleteMoney(int accountNumber, double amountWithdraw);

	public String[] readTransaction(int accountNumber);
}
