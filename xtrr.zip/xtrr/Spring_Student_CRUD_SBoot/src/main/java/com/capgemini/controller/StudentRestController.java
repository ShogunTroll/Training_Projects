package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.Student;
import com.capgemini.service.StudentService;

@RestController
@RequestMapping(value = "students")
public class StudentRestController {

	// http://localhost:9090/students/hello

	@Autowired
	private StudentService service;

	@RequestMapping(value = "hello", method = RequestMethod.GET)
	public String helloWorld() {

		return "Hello class from REST service";

	}

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Student> getAllStudents() {
		List<Student> list = service.findAllStudent();
		return list;

	}

	@RequestMapping(value = "/{id}",method = RequestMethod.GET)
	public Student getStudentById(@PathVariable("id") int studentId) {

		Student student = service.findStudentById(studentId);
		return student;
	}
	
	@RequestMapping(value = "/",method = RequestMethod.POST,
					consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addStudent(@RequestBody Student obj)
	{
		service.addStudent(obj);
		
	}
	
	@RequestMapping(value = "/{id}" ,method = RequestMethod.DELETE)
	public void deleteStudentById(@PathVariable("id") int studentId)
	{
		Student student= service.findStudentById(studentId);
		service.removeStudent(student);
		
		
	}
	
	@RequestMapping(value = "/",method = RequestMethod.PUT)
	public void updateStudent(@RequestBody Student student)
	{
		service.updateStudent(student);
		
	}

}
