package com.cg.JDBCcrud.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cg.JDBCcrud.entities.Student;

public class StudentDaoImpl implements StudentDao {
	private JdbcTemplate jdbcTemplate;


	public StudentDaoImpl() {
		
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public Student getStudentById(int id) {
		String query="select * from students where studentId="+id;
		List<Student> list = jdbcTemplate.query(query,new StudentRowMapper());
		
		return list.get(0);	}

	@Override
	public void addStudent(Student student) {
		String query = "INSERT INTO Students(studentId,name) "
				+ "values("+student.getStudentId()+",'"+student.getName()+"')";
		
		System.out.println(query);
		jdbcTemplate.update(query);
	}

	@Override
	public void removeStudent(Student student) {
		
		String query="Delete From Students where studentId="+student.getStudentId()+"";
		jdbcTemplate.update(query);
	}

	@Override
	public void updateStudent(Student student) {
		String query = "update students set Name='"+student.getName()+"'Where studentId="+student.getStudentId();
		jdbcTemplate.update(query);
	}

	@Override
	public void beginTransaction() {
	}

	@Override
	public void commitTransaction() {
	}
}
