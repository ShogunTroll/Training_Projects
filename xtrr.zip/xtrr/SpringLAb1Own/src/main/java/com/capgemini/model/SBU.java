package com.capgemini.model;

import java.util.ArrayList;
import java.util.List;

public class SBU {
	
	private int sbuId;
	private String sbuName;
	private String sbuHead;
	
	List<Employee> empList=new ArrayList<Employee>();
	
	
	public List<Employee> getEmpList() {
		return empList;
	}


	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}


	public SBU() {
		super();
	}


	public SBU(int sbuId, String sbuName, String sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}


	public int getsbuId() {
		return sbuId;
	}


	public void setsbuId(int sbuId) {
		this.sbuId = sbuId;
	}


	public String getSbuName() {
		return sbuName;
	}


	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}


	public String getsbuHead() {
		return sbuHead;
	}


	public void setsbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}


	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", empList=" + empList + "]";
	}


	
	
	
	

}
