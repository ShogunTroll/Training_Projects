package com.capgemini.model;

public class Employee {
	
	private int empId;
	private String empName;
	private double empSalary;
	private String empSBO;
	private int empAge;
	
	//private SBU bUnit;
	
	
	public Employee() {
		super();
	}

	/*
	 * public SBU getbUnit() { return bUnit; }
	 * 
	 * 
	 * public void setbUnit(SBU bUnit) { this.bUnit = bUnit; }
	 */


	public Employee(int empId, String empName, double empSalary, String empSBO, int empAge) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empSBO = empSBO;
		this.empAge = empAge;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public double getEmpSalary() {
		return empSalary;
	}


	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}


	public String getEmpSBO() {
		return empSBO;
	}


	public void setEmpSBO(String empSBO) {
		this.empSBO = empSBO;
	}


	public int getEmpAge() {
		return empAge;
	}


	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empSBO=" + empSBO
				+ ", empAge=" + empAge +  "]";
	}


	
	
	
	

}
