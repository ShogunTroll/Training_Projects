package com.capgemini.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.model.SBU;

public class Main {

	public static void main(String[] args) {

		BeanFactory factory = new ClassPathXmlApplicationContext("emp-config.xml");

		/*
		 * Employee emp= (Employee) factory.getBean("employee");
		 * System.out.println(emp);
		 * 
		 */

		SBU sbu = (SBU) factory.getBean("sbu");
		System.out.println(sbu);

	}

}
