package com.walletapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transactiontable")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transId;

	@Column(name = "accountnumber")
	private int accountNumber;

	@Column(name = "transaction")
	private String transaction;

	public Transaction(int transId, int accountNumber, String transaction) {
		super();
		this.transId = transId;
		this.accountNumber = accountNumber;
		this.transaction = transaction;
	}

	public Transaction() {
		super();
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Transaction [accountNumber=" + accountNumber + ", transaction=" + transaction + "]";
	}

}
