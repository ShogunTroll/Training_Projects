package com.walletapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "walletaccounttable")
@JsonIgnoreProperties(ignoreUnknown = true)
public class WalletAccount {

	@Id
	@Column(name = "accountnumber")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int accountNumber = 0;

	@Column(name = "name")
	private String accountName = "";

	@Column(name = "email")
	private String email = "";

	@Column(name = "balance")
	private double accountBalance = 0.0;

	@Column(name = "mobileno")
	private long mobileNumber = 0;

	public WalletAccount() {
		super();
	}

	public WalletAccount(String accountName, String email, long mobileNumber) {
		super();
		this.accountName = accountName;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WalletAccount [AccountName=").append(accountName).append(", Email=").append(email)
				.append(", AccountBalance=").append(accountBalance).append(", MobileNumber=").append(mobileNumber)
				.append("]");
		return builder.toString();
	}
}
