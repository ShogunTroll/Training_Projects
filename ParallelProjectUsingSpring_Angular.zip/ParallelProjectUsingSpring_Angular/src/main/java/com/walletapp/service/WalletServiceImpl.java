package com.walletapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walletapp.dao.WalletDao;
import com.walletapp.dao.WalletDaoImpl;
import com.walletapp.model.WalletAccount;

@Service
public class WalletServiceImpl implements WalletService {

	@Autowired
	private WalletDaoImpl dao;

	@Override
	public boolean addAccount(WalletAccount wa) {
		dao.beginTransaction();
		dao.createAccount(wa);
		dao.commitTransaction();
		return true;
	}

	@Override
	public double showBalance(int accountNumber) {
		dao.beginTransaction();
		double result = dao.readBalance(accountNumber);
		dao.commitTransaction();
		return result;
	}

	@Override
	public int depositMoney(int accountNumber, double money) {
		dao.beginTransaction();
		int res = dao.updateMoney(accountNumber, money);
		dao.commitTransaction();
		return res;
	}

	@Override
	public int transferMoney(int accountNumberFrom, int accountNumberTo, double money) {
		dao.beginTransaction();
		int res = dao.transferMoney(accountNumberFrom, accountNumberTo, money);
		dao.commitTransaction();
		return res;
	}

	@Override
	public int withDrawMoney(int accountNumber, double amountWithdraw) {
		dao.beginTransaction();
		int res = dao.deleteMoney(accountNumber, amountWithdraw);
		dao.commitTransaction();
		return res;
	}

	@Override
	public List<String> showTransaction(int accountNumber) {
		dao.beginTransaction();
		List<String> list = dao.readTransaction(accountNumber);
		dao.commitTransaction();
		return list;
	}

	@Override
	public boolean findAccountById(int accountNumber) {
		return dao.findAccountById(accountNumber);
	}

	@Override
	public List<WalletAccount> getAllAccount() {
		return dao.getAllAccount();
	}

}
