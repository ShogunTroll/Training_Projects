package com.walletapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.walletapp.exception.WalletAppTechnicalException;
import com.walletapp.model.WalletAccount;
import com.walletapp.service.WalletServiceImpl;

@RestController
@RequestMapping(value = "/api")
public class WalletAppController {

	@Autowired
	WalletServiceImpl service;

	// http://localhost:9090/api/account
	@RequestMapping(value = "/account", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<WalletAccount> getAllAccount() {
		return service.getAllAccount();
	}

	// http://localhost:9090/api/account/transaction/{accnum}
	@RequestMapping(value = "/account/transaction/{accnum}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> showTransaction(@PathVariable("accnum") int accountNumber) {
		List<String> transList = service.showTransaction(accountNumber);
		if (transList != null) {
			return transList;
		} else {
			throw new WalletAppTechnicalException("Transaction Not Found.");
		}
	}

	// http://localhost:9090/api/account/create
	@RequestMapping(value = "/account/create", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String addAccount(@RequestBody WalletAccount obj) {
		service.addAccount(obj);
		return "Account is created successfully";
	}

	// http://localhost:9090/api/account/deposit/{accnum}/{money}
	@RequestMapping(value = "/account/deposit/{accnum}/{money}", method = RequestMethod.PUT)
	public String depositMoney(@PathVariable("accnum") int accountNumber, @PathVariable("money") double money) {
		if (service.findAccountById(accountNumber)) {
			service.depositMoney(accountNumber, money);
			return "Money deposited successfully";
		} else {
			throw new WalletAppTechnicalException("Account Not Found");
		}
	}

	// http://localhost:9090/api/account/transfer/{accnumfrom}/{accnumto}/{money}
	@RequestMapping(value = "/account/transfer/{accnumfrom}/{accnumto}/{money}", method = RequestMethod.PUT)
	public String transfer(@PathVariable("accnumto") int accountNumberTo,
			@PathVariable("accnumfrom") int accountNumberFrom, @PathVariable("money") double money) {
		service.transferMoney(accountNumberFrom, accountNumberTo, money);
		return "Money is transfered successfully";
	}

	// http://localhost:9090/api/account/withdraw/{accnum}/{money}
	@RequestMapping(value = "/account/withdraw/{accnum}/{money}", method = RequestMethod.DELETE)
	public String withdrawMoney(@PathVariable("accnum") int accountNumber, @PathVariable("money") double money) {
		if (service.findAccountById(accountNumber)) {
			service.withDrawMoney(accountNumber, money);
			return "Money withdrawn successfully";
		} else {
			throw new WalletAppTechnicalException("Account Not Found");
		}
	}
	// http://localhost:9090/api/account/check/{accnum}
	@RequestMapping(value = "/account/check/{accnum}", method = RequestMethod.GET)
	public String checkBalance(@PathVariable("accnum") int accountNumber) {
		service.showBalance(accountNumber);
		return null;
	}
}
