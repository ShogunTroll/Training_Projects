package com.walletapp.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.walletapp.dbutil.JPAUtil;
import com.walletapp.exception.WalletAppTechnicalException;
import com.walletapp.model.Transaction;
import com.walletapp.model.WalletAccount;

@Repository
public class WalletDaoImpl implements WalletDao {

	private static EntityManager entityManager;

	static int accountNumber = 0;

	public WalletDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	public static int getAccountNumber() {
		try {
			Query query = entityManager.createQuery("SELECT w.accountNumber FROM WalletAccount w");
			List<Integer> list = query.getResultList();
			Iterator<Integer> itr = list.iterator();
			while (itr.hasNext()) {
				accountNumber = itr.next();
			}
			accountNumber++;
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while creating account number.");
			throw wap;
		}
		return accountNumber;
	}

	@Override
	public boolean createAccount(WalletAccount wa) {
		try {

			entityManager.persist(wa);
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while creating account.");
			throw wap;
		}
		return true;
	}

	@Override
	public double readBalance(int accountNumber) {
		WalletAccount wa = new WalletAccount();
		double balance = -1;
		int count = 0;
		try {
			TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
					WalletAccount.class);
			List<WalletAccount> list = tqcheck.getResultList();
			Iterator<WalletAccount> itr = list.iterator();
			while (itr.hasNext()) {
				if (itr.next().getAccountNumber() == accountNumber) {
					++count;
					break;
				}
			}
			if (count != 0) {
				TypedQuery<WalletAccount> tq = entityManager.createQuery(
						"SELECT w FROM WalletAccount w WHERE w.accountNumber=:accnum", WalletAccount.class);
				tq.setParameter("accnum", accountNumber);
				wa = tq.getSingleResult();
				balance = wa.getAccountBalance();
			}
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while reading balance.");
			throw wap;
		}
		return balance;
	}

	@Override
	public int updateMoney(int accountNumber, double money) {
		int res = -1, count = 0;
		try {
			TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
					WalletAccount.class);
			List<WalletAccount> list = tqcheck.getResultList();
			Iterator<WalletAccount> itr = list.iterator();
			while (itr.hasNext()) {
				if (itr.next().getAccountNumber() == accountNumber) {
					++count;
					break;
				}
			}
			if (count != 0) {
				Query query = entityManager.createQuery(
						"UPDATE WalletAccount w SET w.accountBalance=w.accountBalance+:newbal WHERE w.accountNumber=:accnum");
				query.setParameter("newbal", money);
				query.setParameter("accnum", accountNumber);
				res = query.executeUpdate();
				String trans = money + " is deposited";
				Transaction transaction = new Transaction();
				transaction.setTransId(transaction.getTransId());
				transaction.setAccountNumber(accountNumber);
				transaction.setTransaction(trans);
				entityManager.persist(transaction);
			}
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while depositing money.");
			throw wap;
		}
		return res;
	}

	@Override
	public int transferMoney(int accountNumberFrom, int accountNumberTo, double money) {
		int res = -1, count = 0;
		try {
			TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
					WalletAccount.class);
			List<WalletAccount> list = tqcheck.getResultList();
			List<WalletAccount> list2 = tqcheck.getResultList();
			Iterator<WalletAccount> itr = list.iterator();
			Iterator<WalletAccount> itr2 = list2.iterator();
			while (itr.hasNext()) {
				if (itr.next().getAccountNumber() == accountNumberFrom) {
					while (itr2.hasNext()) {
						if (itr2.next().getAccountNumber() == accountNumberTo) {
							++count;
							break;
						}
					}
					break;
				}
			}
			if (count != 0) {
				TypedQuery<WalletAccount> tq = entityManager.createQuery(
						"SELECT w FROM WalletAccount w WHERE w.accountNumber=:accnum", WalletAccount.class);
				tq.setParameter("accnum", accountNumberFrom);
				TypedQuery<WalletAccount> tq2 = entityManager.createQuery(
						"SELECT w FROM WalletAccount w WHERE w.accountNumber=:accnum", WalletAccount.class);
				tq2.setParameter("accnum", accountNumberTo);
				WalletAccount wa = tq.getSingleResult();
				WalletAccount wa2 = tq2.getSingleResult();
				double balance = wa.getAccountBalance();
				if (balance >= money) {
					Query query = entityManager.createQuery(
							"UPDATE WalletAccount w SET w.accountBalance=w.accountBalance-:balwith WHERE w.accountNumber=:accnumfrom");
					query.setParameter("balwith", money);
					query.setParameter("accnumfrom", accountNumberFrom);
					res = query.executeUpdate();
					String trans = money + " is transfered to " + wa2.getAccountName();
					Transaction transaction1 = new Transaction();
					transaction1.setTransId(transaction1.getTransId());
					transaction1.setAccountNumber(accountNumberFrom);
					transaction1.setTransaction(trans);
					entityManager.persist(transaction1);

					query = entityManager.createQuery(
							"UPDATE WalletAccount w SET w.accountBalance=w.accountBalance+:transbal WHERE w.accountNumber=:accnumto");
					query.setParameter("transbal", money);
					query.setParameter("accnumto", accountNumberTo);
					res = query.executeUpdate();
					trans = "You receive " + money + " from " + wa.getAccountName();
					Transaction transaction2 = new Transaction();
					transaction2.setTransId(transaction2.getTransId());
					transaction2.setAccountNumber(accountNumberTo);
					transaction2.setTransaction(trans);
					entityManager.persist(transaction2);
				}
			} else {
				return 0;
			}
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while transfering money.");
			throw wap;
		}
		return res;
	}

	@Override
	public int deleteMoney(int accountNumber, double amountWithdraw) {
		int res = -1, count = 0;
		try {
			TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
					WalletAccount.class);
			List<WalletAccount> list = tqcheck.getResultList();
			Iterator<WalletAccount> itr = list.iterator();
			while (itr.hasNext()) {
				if (itr.next().getAccountNumber() == accountNumber) {
					++count;
					break;
				}
			}
			if (count != 0) {
				TypedQuery<WalletAccount> tq = entityManager.createQuery(
						"SELECT w FROM WalletAccount w WHERE w.accountNumber=:accnum", WalletAccount.class);
				tq.setParameter("accnum", accountNumber);
				WalletAccount wa = tq.getSingleResult();
				double balance = wa.getAccountBalance();
				if (balance >= amountWithdraw) {
					Query query = entityManager.createQuery(
							"UPDATE WalletAccount w SET w.accountBalance=w.accountBalance-:balwith WHERE w.accountNumber=:accnum");
					query.setParameter("balwith", amountWithdraw);
					query.setParameter("accnum", accountNumber);
					res = query.executeUpdate();
					String trans = amountWithdraw + " is withdrawn";
					Transaction transaction = new Transaction();
					transaction.setTransId(transaction.getTransId());
					transaction.setAccountNumber(accountNumber);
					transaction.setTransaction(trans);
					entityManager.persist(transaction);
				}
			} else {
				return 0;
			}
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while withdrawing money.");
			throw wap;
		}
		return res;
	}

	@Override
	public List<String> readTransaction(int accountNumber) {
		List<String> list = new ArrayList<>();
		int count = 0;
		try {
			TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
					WalletAccount.class);
			List<WalletAccount> list2 = tqcheck.getResultList();
			Iterator<WalletAccount> itr = list2.iterator();
			while (itr.hasNext()) {
				if (itr.next().getAccountNumber() == accountNumber) {
					++count;
					break;
				}
			}
			if (count != 0) {
				Query query = entityManager
						.createQuery("SELECT t.transaction FROM Transaction t WHERE t.accountNumber=:accnum");
				query.setParameter("accnum", accountNumber);
				list = query.getResultList();
			} else {
				list.add("No Account");
				return list;
			}
		} catch (WalletAppTechnicalException e) {
			WalletAppTechnicalException wap = new WalletAppTechnicalException(
					"There is some technical issue while reading transaction.");
			throw wap;
		}
		return list;
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		entityManager.clear();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public boolean findAccountById(int accountNumber) {
		int count = 0;
		TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
				WalletAccount.class);
		List<WalletAccount> list = tqcheck.getResultList();
		Iterator<WalletAccount> itr = list.iterator();
		while (itr.hasNext()) {
			if (itr.next().getAccountNumber() == accountNumber) {
				++count;
				break;
			}
		}
		if (count == 0) {
			return false;
		}
		return true;
	}

	@Override
	public List<WalletAccount> getAllAccount() {
		TypedQuery<WalletAccount> tqcheck = entityManager.createQuery("SELECT w FROM WalletAccount w",
				WalletAccount.class);
		List<WalletAccount> list = tqcheck.getResultList();
		return list;
	}
}
