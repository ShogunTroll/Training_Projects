package com.walletapp.exception;

public class WalletAppTechnicalException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public WalletAppTechnicalException(String msg) {
		super(msg);
	}
}
