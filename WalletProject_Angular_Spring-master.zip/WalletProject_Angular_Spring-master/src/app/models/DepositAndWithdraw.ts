export class DepositAndWithdraw{
    id:number
    amount:number
}