# WalletProject_Angular_Spring
Wallet Project with Spring as back-end and Angular 6 as front-end.
