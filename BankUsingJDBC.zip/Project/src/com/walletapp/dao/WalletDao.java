package com.walletapp.dao;

import java.util.List;

import com.walletapp.exception.WalletAppException;
import com.walletapp.model.WalletAccount;

public interface WalletDao {
	public boolean createAccount(WalletAccount wa) throws WalletAppException;

	public double readBalance(int accountNumber);

	public int updateMoney(int accountNumber, double money);

	public int transferMoney(int accountNumberFrom, int accountNumberTo, double money);

	public int deleteMoney(int accountNumber, double amountWithdraw);

	public List<String> readTransaction(int accountNumber);
}
