package com.walletapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.walletapp.dbutil.JdUtil;
import com.walletapp.exception.WalletAppException;
import com.walletapp.model.WalletAccount;

public class WalletDaoImpl implements WalletDao {
	private JdUtil dutil = null;

	public WalletDaoImpl() {
		dutil = JdUtil.getInstance();
	}

	static int accountNumber = 0;

	public static int getAccountNumber() {
		return accountNumber;
	}

	@Override
	public boolean createAccount(WalletAccount wa) {
		try {
			Connection con = dutil.openDatabaseConnection();
			String readquery = "select * from walletaccount";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(readquery);
			while (rs.next()) {
				accountNumber = rs.getInt(1);
			}
			++accountNumber;
			String addquery = "Insert into WalletAccount(accountnumber, name, email, mobileno, balance) values(?, ?, ?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(addquery);
			pstmt.setInt(1, accountNumber);
			pstmt.setString(2, wa.getAccountName());
			pstmt.setString(3, wa.getEmail());
			pstmt.setLong(4, wa.getMobileNumber());
			pstmt.setDouble(5, 0);
			int result = pstmt.executeUpdate();
			if (result >= 1) {
				return true;
			}
			pstmt.close();
			dutil.closeDatabaseConnection();
		} catch (SQLException | ClassNotFoundException e) {
			WalletAppException awe = new WalletAppException(e, "There is some technical issue while adding account.");
			throw awe;

		}
		return false;
	}

	@Override
	public double readBalance(int accountNumber) {
		try {
			double newBalance = 0.0;
			Connection con = dutil.openDatabaseConnection();
			String readquery = "select * from walletaccount where accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(readquery);
			pstmt.setInt(1, accountNumber);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				newBalance = result.getDouble(5);
			}
			dutil.closeDatabaseConnection();
			return newBalance;
		} catch (SQLException | ClassNotFoundException e) {
			WalletAppException awe = new WalletAppException(e, "There is some technical issue while reading balance.");
			throw awe;

		}
	}

	@Override
	public int updateMoney(int accountNumber, double money) {
		try {
			Connection con = dutil.openDatabaseConnection();
			String updatequery = "update walletaccount set balance=balance+" + money + "where accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(updatequery);
			pstmt.setInt(1, accountNumber);
			int result = pstmt.executeUpdate();

			String insertquery = "insert into transaction(accountnumber,transaction) values(?,?)";
			pstmt = con.prepareStatement(insertquery);
			String trans = Double.toString(money) + " has been deposited";
			pstmt.setInt(1, accountNumber);
			pstmt.setString(2, trans);
			pstmt.executeUpdate();
			pstmt.close();
			dutil.closeDatabaseConnection();
			return result;
		} catch (SQLException | ClassNotFoundException e) {
			WalletAppException awe = new WalletAppException(e, "There is some technical issue while depositing money.");
			throw awe;

		}

	}

	@Override
	public int transferMoney(int accountNumberFrom, int accountNumberTo, double money) {
		try {
			Connection con = dutil.openDatabaseConnection();
			String reveiverName = "", senderName = "";

			String readquery = "select * from walletaccount where accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(readquery);
			pstmt.setInt(1, accountNumberFrom);
			ResultSet res = pstmt.executeQuery();
			double balance = 0.0;
			while (res.next()) {
				balance = res.getDouble(5);
				senderName = res.getString(2);
			}
			readquery = "select name from walletaccount where accountnumber=?";
			pstmt = con.prepareStatement(readquery);
			pstmt.setInt(1, accountNumberTo);
			res = pstmt.executeQuery();
			res.next();
			reveiverName = res.getString(1);
			if (balance >= money) {
				String trans = "";
				String updatequery = "update walletaccount set balance=balance+" + money + "where accountnumber=?";
				pstmt = con.prepareStatement(updatequery);
				pstmt.setInt(1, accountNumberTo);
				int result = pstmt.executeUpdate();

				// For updating transaction of receiver
				String insertquery = "insert into transaction(accountnumber,transaction) values(?,?)";
				pstmt = con.prepareStatement(insertquery);
				trans = "You receive " + Double.toString(money) + " from " + senderName;
				pstmt.setInt(1, accountNumberTo);
				pstmt.setString(2, trans);
				pstmt.executeUpdate();

				updatequery = "update walletaccount set balance=balance-" + money + "where accountnumber=?";
				pstmt = con.prepareStatement(updatequery);
				pstmt.setInt(1, accountNumberFrom);
				result = pstmt.executeUpdate();

				// For updating transaction of sender
				insertquery = "insert into transaction(accountnumber,transaction) values(?,?)";
				pstmt = con.prepareStatement(insertquery);
				trans = Double.toString(money) + " is transfered to " + reveiverName;
				pstmt.setInt(1, accountNumberFrom);
				pstmt.setString(2, trans);
				pstmt.executeUpdate();
				pstmt.close();
				dutil.closeDatabaseConnection();
				return result;
			} else {
				dutil.closeDatabaseConnection();
				System.out.println("Insufficient balance.");
				return 0;
			}
		} catch (SQLException | ClassNotFoundException e) {
			WalletAppException awe = new WalletAppException(e,
					"There is some technical issue while transfering money.");
			throw awe;
		}
	}

	@Override
	public int deleteMoney(int accountNumber, double amountWithdraw) {
		try {
			Connection con = dutil.openDatabaseConnection();
			String readquery = "select * from walletaccount where accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(readquery);
			pstmt.setInt(1, accountNumber);
			ResultSet res = pstmt.executeQuery();
			Double balance = 0.0;
			while (res.next()) {
				balance = res.getDouble(5);
			}
			if (balance >= amountWithdraw) {
				String updatequery = "update walletaccount set balance=balance-" + amountWithdraw
						+ "where accountnumber=?";
				pstmt = con.prepareStatement(updatequery);
				pstmt.setInt(1, accountNumber);
				int result = pstmt.executeUpdate();

				String insertquery = "insert into transaction(accountnumber,transaction) values(?,?)";
				pstmt = con.prepareStatement(insertquery);
				String trans = Double.toString(amountWithdraw) + " has been withdrawn";
				pstmt.setInt(1, accountNumber);
				pstmt.setString(2, trans);
				pstmt.executeUpdate();
				dutil.closeDatabaseConnection();
				return result;
			} else {
				dutil.closeDatabaseConnection();
				return 0;
			}

		} catch (SQLException | ClassNotFoundException e) {
			WalletAppException awe = new WalletAppException(e,
					"There is some technical issue while withdrawing money.");
			throw awe;

		}

	}

	@Override
	public List<String> readTransaction(int accountNumber) {
		try {
			Connection con = dutil.openDatabaseConnection();
			String readquery = "select * from transaction where accountnumber=?";
			PreparedStatement pstmt = con.prepareStatement(readquery);
			pstmt.setInt(1, accountNumber);
			ResultSet result = pstmt.executeQuery();
			List<String> transaction = new ArrayList<>();
			while (result.next()) {
				transaction.add(result.getString("transaction"));
			}
			dutil.closeDatabaseConnection();
			return transaction;
		} catch (SQLException | ClassNotFoundException e) {
			WalletAppException awe = new WalletAppException(e,
					"There is some technical issue while showing transaction");
			throw awe;
		}
	}
}
