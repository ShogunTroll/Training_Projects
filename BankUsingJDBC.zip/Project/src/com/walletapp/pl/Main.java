package com.walletapp.pl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.walletapp.dao.WalletDaoImpl;
import com.walletapp.exception.WalletAppException;
import com.walletapp.model.WalletAccount;
import com.walletapp.service.Validator;
import com.walletapp.service.WalletService;
import com.walletapp.service.WalletServiceImpl;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		WalletService service = new WalletServiceImpl();
		int choice = 0, accountNumber = 0, accountNumberTo = 0;
		long mobileNumber = 0;
		double money = 0.0, amount = 0.0;
		String accountName = "", email = "";
		boolean flag = true;
		System.out.println("================WELCOME TO WALLET SYSTEM==============");
		while (flag) {
			try {
				System.out.println("1. Create Account");
				System.out.println("2. Check Balance");
				System.out.println("3. Deposit Money");
				System.out.println("4. Transfer Money");
				System.out.println("5. Withdraw Money");
				System.out.println("6. Show Transaction");
				System.out.println("7. Quit");
				while (true) {
					try {
						System.out.print("Enter your choice:");
						choice = scan.nextInt();
					} catch (InputMismatchException e1) {
						scan.nextLine();
						System.out.println("Please enter correct choice.");
					}
					if (choice > 0) {
						break;
					}
				}
				switch (choice) {
				case 1:
					System.out.println("===============CREATE ACCOUNT=============");
					while (true) {
						System.out.print("Enter your name:");
						accountName = scan.next();
						if (Validator.validateData(accountName, Validator.accountNamePattern)) {
							break;
						} else {
							System.out.println("Please enter your name correctly.");
						}
					}
					while (true) {
						System.out.print("Enter your email Id:");
						email = scan.next();
						if (Validator.validateData(email, Validator.emailPattern)) {
							break;
						} else {
							System.out.println("Please enter valid email.");
						}
					}
					while (true) {
						System.out.print("Enter mobile number:");
						try {
							mobileNumber = scan.nextLong();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}

						if (Validator.validateData(Long.toString(mobileNumber), Validator.phoneNumberPattern)) {
							break;
						} else {
							System.out.println("Please enter valid mobile number.");
						}
					}
					WalletAccount wa = new WalletAccount(accountName, email, mobileNumber);
					  if (service.addAccount(wa)) {
						System.out.println("Your account has been created and your account number is:"
								+ WalletDaoImpl.getAccountNumber() + "\n");
					} else {
						System.out.println("Problem occured while creating account.\n");
					}
					break;
				case 2:
					System.out.println("===============CHECK BALANCE=============");
					while (true) {
						System.out.print("Enter your account number:");
						try {
							accountNumber = scan.nextInt();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Integer.toString(accountNumber), Validator.accountNumberPattern)) {
							break;
						} else {
							System.out.println("Please enter correct account number.");
						}
					}
					double balance = service.showBalance(accountNumber);
					System.out.println("Your total balance is " + balance + "\n");
					break;
				case 3:
					System.out.println("===============DEPOSIT MONEY=============");
					while (true) {
						System.out.print("Enter your account number:");
						try {
							accountNumber = scan.nextInt();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Integer.toString(accountNumber), Validator.accountNumberPattern)) {
							break;
						} else {
							System.out.println("Please enter correct account number.");
						}
					}
					while (true) {
						System.out.print("Enter amount to deposit:");
						try {
							money = scan.nextDouble();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Double.toString(money), Validator.amountPattern) && money >= 100.0) {
							break;
						} else {
							System.out.println("Please enter amount greater than or equal to 100.");
						}
					}
					double newBalance = service.depositMoney(accountNumber, money);
					if (newBalance >= 1)
						System.out.println(money + " has been deposited successfully.");
					else
						System.out.println("Problem while deposting money.\n");
					break;
				case 4:
					System.out.println("===============TRANSFER MONEY=============");
					while (true) {
						try {
							System.out.print("Enter money sender account number:");
							accountNumber = scan.nextInt();
							System.out.print("Enter money receiver account number:");
							accountNumberTo = scan.nextInt();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if ((Validator.validateData(Integer.toString(accountNumber), Validator.accountNumberPattern)
								&& Validator.validateData(Integer.toString(accountNumberTo),
										Validator.accountNumberPattern))
								&& accountNumber != accountNumberTo) {
							break;
						} else {
							System.out.println("Please enter correct account number.");
						}
					}
					while (true) {
						System.out.print("Enter amount to transfer:");
						try {
							money = scan.nextDouble();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Double.toString(money), Validator.amountPattern) && money >= 100.0) {
							break;
						} else {
							System.out.println("Please enter amount greater than or equal to 100.");
						}
					}
					amount = service.transferMoney(accountNumber, accountNumberTo, money);
					if (amount > 0) {
						System.out.println("Amount:" + money + " is transfered to account id:" + accountNumberTo
								+ " successfully.\n");
					} else {
						System.out.println("Problem while transfering money.\n");
					}
					break;
				case 5:
					System.out.println("===============WITHDRAW MONEY=============");
					while (true) {
						System.out.print("Enter your account number:");
						try {
							accountNumber = scan.nextInt();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Integer.toString(accountNumber), Validator.accountNumberPattern)) {
							break;
						} else {
							System.out.println("Please enter correct account number.");
						}
					}
					while (true) {
						System.out.print("Enter amount to withdraw:");
						try {
							money = scan.nextDouble();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Double.toString(money), Validator.amountPattern) && money >= 100.0) {
							break;
						} else {
							System.out.println("Please enter amount greater than or equal to 100.");
						}
					}
					int check = service.withDrawMoney(accountNumber, money);
					if (check >= 1) {
						System.out.println(money + " is withdrawn successfully from your account.\n");
					} else {
						System.out.println("Insufficient balance.");
					}
					break;
				case 6:
					System.out.println("===============PRINT TRANSACTION=============");
					while (true) {
						System.out.print("Enter account number:");
						try {
							accountNumber = scan.nextInt();
						} catch (InputMismatchException e) {
							scan.nextLine();
						}
						if (Validator.validateData(Integer.toString(accountNumber), Validator.accountNumberPattern)) {
							break;
						} else {
							System.out.println("Please enter correct account number.");
						}
					}
					List<String> transaction = new ArrayList<String>();
					transaction = service.showTransaction(accountNumber);
					if (transaction != null) {
						System.out.println("==================Transaction Details=================");
						Iterator<String> itr = transaction.iterator();
						while (itr.hasNext()) {
							System.out.println(itr.next());
						}
					} else {
						System.out.println("No transaction to read.\n");
					}
					break;
				case 7:
					flag = false;
					break;
				default:
					System.out.println("Wrong choice, Please try again.\n");
				}
			} catch (WalletAppException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		scan.close();
	}
}
