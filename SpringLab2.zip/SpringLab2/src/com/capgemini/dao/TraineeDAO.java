package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Trainee;


public interface TraineeDAO  {

	Trainee find(int TraineeId);
    List<Trainee> getAll();
    void create(Trainee t);
    void delete(Integer t);
    void modify(Trainee t);
}
