package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.TraineeDAO;
import com.capgemini.model.Trainee;

@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	private TraineeDAO dao;

	public Trainee find(int TraineeId) {
		return dao.find(TraineeId);
	}

	public List<Trainee> getAll() {
		return dao.getAll();
	}

	public void create(Trainee t) {
		dao.create(t);
	}

	public void delete(Integer t) {
		dao.delete(t);
	}

	public void modify(Trainee t) {
		dao.modify(t);
	}
}
