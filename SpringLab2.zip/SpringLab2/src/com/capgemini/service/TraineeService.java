package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Trainee;

public interface TraineeService {

	Trainee find(int TraineeId);

	List<Trainee> getAll();

	void create(Trainee t);

	void delete(Integer t);

	void modify(Trainee t);
}
